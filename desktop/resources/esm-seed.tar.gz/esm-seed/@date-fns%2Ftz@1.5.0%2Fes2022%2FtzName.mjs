/* esm.sh - @date-fns/tz@1.5.0/tzName */
function o(e,n,t="long"){return new Intl.DateTimeFormat("en-US",{hour:"numeric",timeZone:e,timeZoneName:t}).format(n).split(/\s/g).slice(2).join(" ")}export{o as tzName};
//# sourceMappingURL=tzName.mjs.map