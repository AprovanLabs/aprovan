/* esm.sh - date-fns@4.4.0/daysToWeeks */
import{daysInWeek as r}from"./constants.mjs";function o(e){let t=Math.trunc(e/r);return t===0?0:t}var s=o;export{o as daysToWeeks,s as default};
//# sourceMappingURL=daysToWeeks.mjs.map