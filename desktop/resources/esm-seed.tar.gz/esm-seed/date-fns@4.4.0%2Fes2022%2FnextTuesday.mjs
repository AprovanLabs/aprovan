/* esm.sh - date-fns@4.4.0/nextTuesday */
import{nextDay as r}from"./nextDay.mjs";function n(t,e){return r(t,2,e)}var u=n;export{u as default,n as nextTuesday};
//# sourceMappingURL=nextTuesday.mjs.map