/* esm.sh - date-fns@4.4.0/startOfISOWeek */
import{startOfWeek as r}from"./startOfWeek.mjs";function f(t,e){return r(t,{...e,weekStartsOn:1})}var a=f;export{a as default,f as startOfISOWeek};
//# sourceMappingURL=startOfISOWeek.mjs.map