/* esm.sh - es-toolkit@1.50.0/dist/predicate/isBuffer */
import{globalThis_ as f}from"../_internal/globalThis.mjs";function u(e){return typeof f.Buffer<"u"&&f.Buffer.isBuffer(e)}export{u as isBuffer};
//# sourceMappingURL=isBuffer.mjs.map