/* esm.sh - date-fns@4.4.0/previousTuesday */
import{previousDay as o}from"./previousDay.mjs";function t(r,e){return o(r,2,e)}var p=t;export{p as default,t as previousTuesday};
//# sourceMappingURL=previousTuesday.mjs.map