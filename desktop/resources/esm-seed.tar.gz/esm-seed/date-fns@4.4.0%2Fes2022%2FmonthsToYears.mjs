/* esm.sh - date-fns@4.4.0/monthsToYears */
import{monthsInYear as o}from"./constants.mjs";function n(t){let r=t/o;return Math.trunc(r)}var a=n;export{a as default,n as monthsToYears};
//# sourceMappingURL=monthsToYears.mjs.map