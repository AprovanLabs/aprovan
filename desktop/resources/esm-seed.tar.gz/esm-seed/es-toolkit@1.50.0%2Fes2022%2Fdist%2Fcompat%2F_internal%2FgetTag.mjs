/* esm.sh - es-toolkit@1.50.0/dist/compat/_internal/getTag */
function e(t){return t==null?t===void 0?"[object Undefined]":"[object Null]":Object.prototype.toString.call(t)}export{e as getTag};
//# sourceMappingURL=getTag.mjs.map