/* esm.sh - es-toolkit@1.50.0/dist/function/ary */
function e(n,r){return function(...t){return n.apply(this,t.slice(0,r))}}export{e as ary};
//# sourceMappingURL=ary.mjs.map