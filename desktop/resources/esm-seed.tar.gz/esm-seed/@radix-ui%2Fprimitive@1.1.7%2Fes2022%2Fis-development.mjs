/* esm.sh - @radix-ui/primitive@1.1.7/is-development */
var E=!1;export{E as IS_DEVELOPMENT};
//# sourceMappingURL=is-development.mjs.map