/* esm.sh - @radix-ui/react-use-callback-ref@1.0.0 */
import{useRef as c,useEffect as a,useMemo as s}from"/esm/react@18.3.1/es2022/react.mjs";function l(f){let e=c(f);return a(()=>{e.current=f}),s(()=>(...u)=>{var r;return(r=e.current)===null||r===void 0?void 0:r.call(e,...u)},[])}export{l as useCallbackRef};
//# sourceMappingURL=react-use-callback-ref.mjs.map