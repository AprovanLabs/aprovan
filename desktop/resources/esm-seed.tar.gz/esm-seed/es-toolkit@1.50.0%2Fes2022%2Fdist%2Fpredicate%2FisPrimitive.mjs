/* esm.sh - es-toolkit@1.50.0/dist/predicate/isPrimitive */
function i(t){return t==null||typeof t!="object"&&typeof t!="function"}export{i as isPrimitive};
//# sourceMappingURL=isPrimitive.mjs.map