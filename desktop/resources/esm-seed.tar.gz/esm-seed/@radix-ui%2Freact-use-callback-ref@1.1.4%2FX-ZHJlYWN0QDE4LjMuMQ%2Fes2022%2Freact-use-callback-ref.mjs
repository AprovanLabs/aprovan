/* esm.sh - @radix-ui/react-use-callback-ref@1.1.4 */
import*as e from"/esm/react@18.3.1/es2022/react.mjs";var c=Object.defineProperty,f=(r,t)=>c(r,"name",{value:t,configurable:!0});function u(r){let t=e.useRef(r);return e.useEffect(()=>{t.current=r}),e.useMemo(()=>((...a)=>t.current?.(...a)),[])}f(u,"useCallbackRef");export{u as useCallbackRef};
//# sourceMappingURL=react-use-callback-ref.mjs.map