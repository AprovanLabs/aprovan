/* esm.sh - es-toolkit@1.50.0/dist/compat/predicate/isArray */
function a(r){return Array.isArray(r)}export{a as isArray};
//# sourceMappingURL=isArray.mjs.map