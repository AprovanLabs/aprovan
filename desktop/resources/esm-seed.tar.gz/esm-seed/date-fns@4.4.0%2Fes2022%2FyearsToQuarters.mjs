/* esm.sh - date-fns@4.4.0/yearsToQuarters */
import{quartersInYear as t}from"./constants.mjs";function e(r){return Math.trunc(r*t)}var o=e;export{o as default,e as yearsToQuarters};
//# sourceMappingURL=yearsToQuarters.mjs.map