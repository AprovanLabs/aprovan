/* esm.sh - @radix-ui/react-use-layout-effect@1.0.0 */
import{useLayoutEffect as o}from"/esm/react@18.3.1/es2022/react.mjs";var e=globalThis?.document?o:()=>{};export{e as useLayoutEffect};
//# sourceMappingURL=react-use-layout-effect.mjs.map