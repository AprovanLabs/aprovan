/* esm.sh - es-toolkit@1.50.0/compat/last */
import{last as n}from"../dist/array/last.mjs";function t(r){return Array.isArray(r)?r:Array.from(r)}import{isLength as i}from"../dist/predicate/isLength.mjs";function o(r){return r!=null&&typeof r!="function"&&i(r.length)}function f(r){if(o(r))return n(t(r))}export{f as default};
//# sourceMappingURL=last.mjs.map