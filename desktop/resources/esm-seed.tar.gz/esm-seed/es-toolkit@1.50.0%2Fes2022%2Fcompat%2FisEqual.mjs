/* esm.sh - es-toolkit@1.50.0/compat/isEqual */
import{isEqual as f}from"../dist/predicate/isEqual.mjs";export{f as default};
//# sourceMappingURL=isEqual.mjs.map