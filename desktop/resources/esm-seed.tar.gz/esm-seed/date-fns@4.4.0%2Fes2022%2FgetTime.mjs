/* esm.sh - date-fns@4.4.0/getTime */
import{toDate as e}from"./toDate.mjs";function o(t){return+e(t)}var f=o;export{f as default,o as getTime};
//# sourceMappingURL=getTime.mjs.map