/* esm.sh - date-fns@4.4.0/hoursToMinutes */
import{minutesInHour as r}from"./constants.mjs";function o(t){return Math.trunc(t*r)}var n=o;export{n as default,o as hoursToMinutes};
//# sourceMappingURL=hoursToMinutes.mjs.map