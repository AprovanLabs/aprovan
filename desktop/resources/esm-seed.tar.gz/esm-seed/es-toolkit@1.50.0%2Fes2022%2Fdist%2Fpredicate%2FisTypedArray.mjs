/* esm.sh - es-toolkit@1.50.0/dist/predicate/isTypedArray */
function e(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}export{e as isTypedArray};
//# sourceMappingURL=isTypedArray.mjs.map