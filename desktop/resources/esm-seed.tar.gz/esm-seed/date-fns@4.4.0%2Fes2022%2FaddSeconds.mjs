/* esm.sh - date-fns@4.4.0/addSeconds */
import{addMilliseconds as r}from"./addMilliseconds.mjs";function t(d,o,e){return r(d,o*1e3,e)}var i=t;export{t as addSeconds,i as default};
//# sourceMappingURL=addSeconds.mjs.map