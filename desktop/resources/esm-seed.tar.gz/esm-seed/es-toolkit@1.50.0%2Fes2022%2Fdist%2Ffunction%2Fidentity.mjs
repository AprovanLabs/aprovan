/* esm.sh - es-toolkit@1.50.0/dist/function/identity */
function n(t){return t}export{n as identity};
//# sourceMappingURL=identity.mjs.map