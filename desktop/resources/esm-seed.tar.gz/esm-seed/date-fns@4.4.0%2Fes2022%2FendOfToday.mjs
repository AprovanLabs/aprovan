/* esm.sh - date-fns@4.4.0/endOfToday */
import{endOfDay as o}from"./endOfDay.mjs";function t(e){return o(Date.now(),e)}var r=t;export{r as default,t as endOfToday};
//# sourceMappingURL=endOfToday.mjs.map