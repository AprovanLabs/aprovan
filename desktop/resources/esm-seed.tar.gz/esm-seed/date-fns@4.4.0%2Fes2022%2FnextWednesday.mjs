/* esm.sh - date-fns@4.4.0/nextWednesday */
import{nextDay as n}from"./nextDay.mjs";function r(e,t){return n(e,3,t)}var x=r;export{x as default,r as nextWednesday};
//# sourceMappingURL=nextWednesday.mjs.map