/* esm.sh - date-fns@4.4.0/getSeconds */
import{toDate as e}from"./toDate.mjs";function o(t){return e(t).getSeconds()}var n=o;export{n as default,o as getSeconds};
//# sourceMappingURL=getSeconds.mjs.map