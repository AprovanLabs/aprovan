/* esm.sh - es-toolkit@1.50.0/dist/_internal/isUnsafeProperty */
function o(r){return r==="__proto__"}export{o as isUnsafeProperty};
//# sourceMappingURL=isUnsafeProperty.mjs.map