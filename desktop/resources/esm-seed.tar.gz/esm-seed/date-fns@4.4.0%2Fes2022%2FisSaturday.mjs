/* esm.sh - date-fns@4.4.0/isSaturday */
import{toDate as e}from"./toDate.mjs";function o(t,r){return e(t,r?.in).getDay()===6}var i=o;export{i as default,o as isSaturday};
//# sourceMappingURL=isSaturday.mjs.map