/* esm.sh - date-fns@4.4.0/hoursToMilliseconds */
import{millisecondsInHour as r}from"./constants.mjs";function t(o){return Math.trunc(o*r)}var e=t;export{e as default,t as hoursToMilliseconds};
//# sourceMappingURL=hoursToMilliseconds.mjs.map