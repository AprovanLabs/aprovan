/* esm.sh - @date-fns/tz@1.5.0/constants */
var o=Symbol.for("constructDateFrom");export{o as constructFromSymbol};
//# sourceMappingURL=constants.mjs.map