/* esm.sh - es-toolkit@1.50.0/dist/predicate/isEqual */
import{noop as i}from"../function/noop.mjs";import{isEqualWith as t}from"./isEqualWith.mjs";function p(o,r){return t(o,r,i)}export{p as isEqual};
//# sourceMappingURL=isEqual.mjs.map