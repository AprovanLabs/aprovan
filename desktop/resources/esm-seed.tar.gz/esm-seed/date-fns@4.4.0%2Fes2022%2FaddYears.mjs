/* esm.sh - date-fns@4.4.0/addYears */
import{addMonths as d}from"./addMonths.mjs";function e(r,t,o){return d(r,t*12,o)}var n=e;export{e as addYears,n as default};
//# sourceMappingURL=addYears.mjs.map