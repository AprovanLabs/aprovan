/* esm.sh - es-toolkit@1.50.0/dist/array/uniqBy */
function c(e,i){let n=new Map;for(let t=0;t<e.length;t++){let o=e[t],s=i(o,t,e);n.has(s)||n.set(s,o)}return Array.from(n.values())}export{c as uniqBy};
//# sourceMappingURL=uniqBy.mjs.map