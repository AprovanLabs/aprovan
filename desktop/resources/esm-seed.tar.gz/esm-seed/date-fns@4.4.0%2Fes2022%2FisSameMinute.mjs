/* esm.sh - date-fns@4.4.0/isSameMinute */
import{startOfMinute as t}from"./startOfMinute.mjs";function i(e,r){return+t(e)==+t(r)}var o=i;export{o as default,i as isSameMinute};
//# sourceMappingURL=isSameMinute.mjs.map