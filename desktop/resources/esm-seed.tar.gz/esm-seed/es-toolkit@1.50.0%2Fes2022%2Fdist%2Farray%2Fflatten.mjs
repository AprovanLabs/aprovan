/* esm.sh - es-toolkit@1.50.0/dist/array/flatten */
function c(l,f=1){let o=[],i=Math.floor(f),r=(s,n)=>{for(let t=0;t<s.length;t++){let e=s[t];Array.isArray(e)&&n<i?r(e,n+1):o.push(e)}};return r(l,0),o}export{c as flatten};
//# sourceMappingURL=flatten.mjs.map