/* esm.sh - es-toolkit@1.50.0/dist/object/cloneDeep */
import{cloneDeepWithImpl as o}from"./cloneDeepWith.mjs";function p(e){return o(e,void 0,e,new Map,void 0)}export{p as cloneDeep};
//# sourceMappingURL=cloneDeep.mjs.map