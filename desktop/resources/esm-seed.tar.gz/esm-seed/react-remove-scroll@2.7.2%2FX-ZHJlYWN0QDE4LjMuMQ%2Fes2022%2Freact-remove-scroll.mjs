/* esm.sh - react-remove-scroll@2.7.2 */
import r from"./dist/es2015/Combination.mjs";export{r as RemoveScroll};
//# sourceMappingURL=react-remove-scroll.mjs.map