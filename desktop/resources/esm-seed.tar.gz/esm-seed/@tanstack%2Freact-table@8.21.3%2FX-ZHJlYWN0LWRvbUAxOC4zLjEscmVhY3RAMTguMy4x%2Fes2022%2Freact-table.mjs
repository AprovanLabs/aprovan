/* esm.sh - @tanstack/react-table@8.21.3 */
import*as r from"/esm/react@18.3.1/es2022/react.mjs";import{createTable as s}from"/esm/@tanstack/table-core@8.21.3/es2022/table-core.mjs";export*from"/esm/@tanstack/table-core@8.21.3/es2022/table-core.mjs";function y(t,e){return t?f(t)?r.createElement(t,e):t:null}function f(t){return l(t)||typeof t=="function"||i(t)}function l(t){return typeof t=="function"&&(()=>{let e=Object.getPrototypeOf(t);return e.prototype&&e.prototype.isReactComponent})()}function i(t){return typeof t=="object"&&typeof t.$$typeof=="symbol"&&["react.memo","react.forward_ref"].includes(t.$$typeof.description)}function R(t){let e={state:{},onStateChange:()=>{},renderFallbackValue:null,...t},[n]=r.useState(()=>({current:s(e)})),[o,c]=r.useState(()=>n.current.initialState);return n.current.setOptions(u=>({...u,...t,state:{...o,...t.state},onStateChange:a=>{c(a),t.onStateChange==null||t.onStateChange(a)}})),n.current}export{y as flexRender,R as useReactTable};
/*! Bundled license information:

@tanstack/react-table/build/lib/index.mjs:
  (**
     * react-table
     *
     * Copyright (c) TanStack
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE.md file in the root directory of this source tree.
     *
     * @license MIT
     *)
*/
//# sourceMappingURL=react-table.mjs.map