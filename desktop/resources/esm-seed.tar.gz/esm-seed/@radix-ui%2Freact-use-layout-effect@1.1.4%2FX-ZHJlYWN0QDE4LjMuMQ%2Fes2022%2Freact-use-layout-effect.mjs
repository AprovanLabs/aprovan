/* esm.sh - @radix-ui/react-use-layout-effect@1.1.4 */
import*as t from"/esm/react@18.3.1/es2022/react.mjs";var e=globalThis?.document?t.useLayoutEffect:()=>{};export{e as useLayoutEffect};
//# sourceMappingURL=react-use-layout-effect.mjs.map