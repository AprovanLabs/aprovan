/* esm.sh - date-fns@4.4.0/subDays */
import{addDays as a}from"./addDays.mjs";function e(r,t,o){return a(r,-t,o)}var d=e;export{d as default,e as subDays};
//# sourceMappingURL=subDays.mjs.map