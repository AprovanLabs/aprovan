/* esm.sh - d3-format@3.1.2/src/defaultLocale */
import t from"./locale.mjs";var r,e,f;o({thousands:",",grouping:[3],currency:["$",""]});function o(a){return r=t(a),e=r.format,f=r.formatPrefix,r}export{o as default,e as format,f as formatPrefix};
//# sourceMappingURL=defaultLocale.mjs.map