/* esm.sh - @radix-ui/react-compose-refs@1.0.0 */
import{useCallback as c}from"/esm/react@18.3.1/es2022/react.mjs";function n(e,f){typeof e=="function"?e(f):e!=null&&(e.current=f)}function t(...e){return f=>e.forEach(o=>n(o,f))}function u(...e){return c(t(...e),e)}export{t as composeRefs,u as useComposedRefs};
//# sourceMappingURL=react-compose-refs.mjs.map