/* esm.sh - es-toolkit@1.50.0/dist/array/last */
function n(t){return t[t.length-1]}export{n as last};
//# sourceMappingURL=last.mjs.map