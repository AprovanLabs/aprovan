/* esm.sh - @radix-ui/primitive@1.0.0 */
function o(e,f,{checkForDefaultPrevented:t=!0}={}){return function(c){if(e?.(c),t===!1||!c.defaultPrevented)return f?.(c)}}export{o as composeEventHandlers};
//# sourceMappingURL=primitive.mjs.map