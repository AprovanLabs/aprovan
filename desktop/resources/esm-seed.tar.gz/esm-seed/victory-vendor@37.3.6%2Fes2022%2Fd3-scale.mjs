/* esm.sh - victory-vendor@37.3.6/d3-scale */
export*from"/esm/d3-scale@^4.0.2?target=es2022";
//# sourceMappingURL=d3-scale.mjs.map