/* esm.sh - date-fns@4.4.0/getHours */
import{toDate as r}from"./toDate.mjs";function e(t,o){return r(t,o?.in).getHours()}var n=e;export{n as default,e as getHours};
//# sourceMappingURL=getHours.mjs.map