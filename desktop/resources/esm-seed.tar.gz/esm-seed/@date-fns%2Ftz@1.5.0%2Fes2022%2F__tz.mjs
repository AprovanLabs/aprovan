/* esm.sh - @date-fns/tz@1.5.0/tz */
import{TZDate as o}from"./date.mjs";var a=t=>e=>o.tz(t,+new Date(e));export{a as tz};
//# sourceMappingURL=__tz.mjs.map