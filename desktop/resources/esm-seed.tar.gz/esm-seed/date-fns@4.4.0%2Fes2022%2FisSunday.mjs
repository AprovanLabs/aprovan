/* esm.sh - date-fns@4.4.0/isSunday */
import{toDate as o}from"./toDate.mjs";function r(t,e){return o(t,e?.in).getDay()===0}var a=r;export{a as default,r as isSunday};
//# sourceMappingURL=isSunday.mjs.map