/* esm.sh - d3-time-format@4.1.0/src/isoFormat */
import{utcFormat as o}from"./defaultLocale.mjs";var r="%Y-%m-%dT%H:%M:%S.%LZ";function e(t){return t.toISOString()}var a=Date.prototype.toISOString?e:o(r),f=a;export{f as default,r as isoSpecifier};
//# sourceMappingURL=isoFormat.mjs.map