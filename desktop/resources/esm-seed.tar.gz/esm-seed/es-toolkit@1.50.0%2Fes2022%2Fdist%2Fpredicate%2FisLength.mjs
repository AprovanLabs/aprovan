/* esm.sh - es-toolkit@1.50.0/dist/predicate/isLength */
function n(e){return Number.isSafeInteger(e)&&e>=0}export{n as isLength};
//# sourceMappingURL=isLength.mjs.map